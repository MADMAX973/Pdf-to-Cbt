# NEET PDF-to-CBT (free starter)

Local-first web app starter. Current features: PDF upload, page rendering, page preview, and Gemini-powered analysis of an uploaded question image.

## Requirements
- Python 3.10+
- Node.js 18+
- A Gemini API key for AI analysis (get one in Google AI Studio). The app works for PDF upload/preview without it.

## Backend setup
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Put your key in backend/.env as GEMINI_API_KEY=...
uvicorn app.main:app --reload
```
Backend docs: http://localhost:8000/docs

## Frontend setup (second terminal)
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173

## Gemini analysis
The API key is read only by the Python backend. Never put it in React code or commit `.env`.
The Analyze Question feature sends the selected page image to Gemini and requests structured fields: question, options, suggested answer, explanation, subject, and confidence. Treat AI answers as suggestions; verify them against a trusted key or subject expert before grading.

## Roadmap
1. PDF upload + page preview + Gemini image analysis (included)
2. Question detection and per-question cropping
3. Manual crop correction/review and answer-key editor
4. Question bank and test builder
5. CBT interface: timer, question palette, navigation, mark for review
6. NEET marking (+4/-1), results and analytics
7. Export/import and end-to-end testing

## Accuracy and privacy
Question-boundary detection is not yet implemented. The current page-level preview is not a substitute for per-question cropping. Gemini may make mistakes, especially with ambiguous diagrams, low-resolution scans, or multi-step calculations. Review every extracted answer. Uploaded PDFs and rendered pages are stored locally in `backend/data/`.
