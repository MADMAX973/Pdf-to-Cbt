import os, json
from pathlib import Path
from dotenv import load_dotenv
from google import genai
from google.genai import types

BASE = Path(__file__).resolve().parents[1]
load_dotenv(BASE / ".env")

def analyse_question(question_text: str, image_path: str | None = None):
    """Return a structured, explicitly unverified AI suggestion for one NEET question."""
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("Gemini is not configured. Add GEMINI_API_KEY to backend/.env.")
    client = genai.Client(api_key=api_key)
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

    prompt = """
You are assisting with review of a NEET multiple-choice question.
Read the supplied question faithfully. Do not invent missing text or options.
Solve it independently and return ONLY valid JSON with this schema:
{
 "subject": "Physics | Chemistry | Biology | Unknown",
 "topic": "short topic name or Unknown",
 "question_type": "single_correct | assertion_reason | statement_based | numerical | other",
 "transcription": "faithful transcription; preserve symbols as well as possible",
 "options": {"A":"...", "B":"...", "C":"...", "D":"..."},
 "suggested_answer": "A | B | C | D | Uncertain",
 "explanation": "concise step-by-step reasoning",
 "confidence": "high | medium | low",
 "needs_human_review": true,
 "warnings": ["list any ambiguity, unreadable symbols, missing options, or assumptions"]
}
Important:
- Never claim certainty when the image/text is unclear.
- For Biology, distinguish textbook facts from assumptions.
- For Physics/Chemistry, show the key equation or reasoning in explanation.
- If options or question are incomplete, set suggested_answer to Uncertain.
- Always set needs_human_review to true. This is a suggestion, not an official answer key.
"""
    parts = [prompt, f"Question text (may be incomplete):\n{question_text or '[No selectable text]'}"]
    if image_path:
        p = Path(image_path)
        if p.exists():
            parts.append(types.Part.from_bytes(data=p.read_bytes(), mime_type="image/png"))
    response = client.models.generate_content(
        model=model,
        contents=parts,
        config=types.GenerateContentConfig(response_mime_type="application/json")
    )
    try:
        return json.loads(response.text)
    except Exception:
        return {
            "suggested_answer": "Uncertain",
            "explanation": response.text or "Gemini returned no readable response.",
            "confidence": "low",
            "needs_human_review": True,
            "warnings": ["Could not parse the model response as JSON."]
        }
