from pathlib import Path
from uuid import uuid4
import os, re
import fitz
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from google import genai
from google.genai import types

BASE = Path(__file__).resolve().parents[1]
load_dotenv(BASE / ".env")
DATA = BASE / "data"
UPLOADS, RENDERS = DATA / "uploads", DATA / "renders"
for folder in (UPLOADS, RENDERS):
    folder.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="NEET PDF-to-CBT API", version="0.2.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)
app.mount("/files", StaticFiles(directory=DATA), name="files")

@app.get("/api/health")
def health():
    return {"status": "ok", "gemini_configured": bool(os.getenv("GEMINI_API_KEY"))}

@app.post("/api/papers")
async def upload_paper(file: UploadFile = File(...)):
    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(400, "Please upload a PDF file.")
    raw = await file.read()
    if len(raw) > 100 * 1024 * 1024:
        raise HTTPException(413, "PDF exceeds the 100 MB starter limit.")
    if not raw.startswith(b"%PDF"):
        raise HTTPException(400, "The uploaded file does not appear to be a valid PDF.")
    paper_id = uuid4().hex[:12]
    pdf_path = UPLOADS / f"{paper_id}.pdf"
    pdf_path.write_bytes(raw)
    try:
        doc = fitz.open(pdf_path)
        pages = []
        for i, page in enumerate(doc):
            pix = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5), alpha=False)
            name = f"{paper_id}-page-{i+1}.png"
            pix.save(RENDERS / name)
            text = page.get_text("text")
            nums = [int(m.group(1)) for m in re.finditer(r"(?m)^\\s*(\\d{1,3})[.)]\\s+", text)]
            pages.append({"page_number": i+1, "image_url": f"/files/renders/{name}",
                          "text_available": bool(text.strip()), "detected_question_numbers": nums})
        count = len(doc)
        doc.close()
        return {"paper_id": paper_id, "filename": file.filename, "page_count": count, "pages": pages}
    except Exception as exc:
        pdf_path.unlink(missing_ok=True)
        raise HTTPException(422, f"Could not process this PDF: {exc}")

@app.post("/api/analyze-question")
async def analyze_question(image: UploadFile = File(...)):
    """Analyze one question crop/page image with Gemini. AI answer is advisory, not verified."""
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise HTTPException(503, "Gemini is not configured. Add GEMINI_API_KEY to backend/.env and restart the backend.")
    mime = image.content_type or "image/png"
    if mime not in ("image/png", "image/jpeg", "image/webp"):
        raise HTTPException(400, "Upload a PNG, JPEG, or WebP question image.")
    raw = await image.read()
    if len(raw) > 15 * 1024 * 1024:
        raise HTTPException(413, "Question image exceeds the 15 MB limit.")
    schema = {
      "type": "OBJECT",
      "properties": {
        "question_text": {"type": "STRING"},
        "options": {"type": "ARRAY", "items": {"type": "STRING"}},
        "suggested_correct_option": {"type": "STRING", "description": "Option label such as A, B, C, D; use UNKNOWN if not determinable."},
        "explanation": {"type": "STRING"},
        "subject": {"type": "STRING", "description": "Physics, Chemistry, Biology, or Unknown"},
        "confidence": {"type": "NUMBER", "description": "Confidence from 0 to 1"},
        "needs_human_review": {"type": "BOOLEAN"},
        "uncertainties": {"type": "ARRAY", "items": {"type": "STRING"}}
      },
      "required": ["question_text", "options", "suggested_correct_option", "explanation",
                   "subject", "confidence", "needs_human_review", "uncertainties"]
    }
    prompt = """You are assisting with NEET question analysis.
Read the uploaded image faithfully. Do not invent missing words, options, symbols, or diagram labels.
Solve the question independently and explain the reasoning concisely.
If any part is unreadable, ambiguous, cropped, or dependent on missing diagram information, say so and set needs_human_review=true.
Do not claim certainty when uncertain. suggested_correct_option must be A/B/C/D only when supported; otherwise UNKNOWN.
Preserve the original question wording in question_text as closely as possible."""
    try:
        client = genai.Client(api_key=api_key)
        response = client.models.generate_content(
            model=os.getenv("GEMINI_MODEL", "gemini-3.8-flash"),
            contents=[prompt, types.Part.from_bytes(data=raw, mime_type=mime)],
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=schema,
                temperature=0.1,
            ),
        )
        import json
        return {"analysis": json.loads(response.text), "model": os.getenv("GEMINI_MODEL", "gemini-3.8-flash"),
                "status": "AI_SUGGESTION_REQUIRES_REVIEW"}
    except Exception as exc:
        raise HTTPException(502, f"Gemini analysis failed: {exc}")
