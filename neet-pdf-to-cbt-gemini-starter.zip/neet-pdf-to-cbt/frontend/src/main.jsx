import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {Upload, FileText, CheckCircle2, AlertCircle, Brain, BookOpen} from 'lucide-react';
import './style.css';
const API='http://localhost:8000';
function App(){
 const [paper,setPaper]=useState(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const [idx,setIdx]=useState(0),[analysis,setAnalysis]=useState(null),[analyzing,setAnalyzing]=useState(false);
 async function upload(e){const f=e.target.files?.[0];if(!f)return;setError('');setPaper(null);setBusy(true);const d=new FormData();d.append('file',f);
  try{const r=await fetch(API+'/api/papers',{method:'POST',body:d});const j=await r.json();if(!r.ok)throw Error(j.detail||'Upload failed');setPaper(j);setIdx(0);setAnalysis(null)}
  catch(x){setError(x.message)}finally{setBusy(false);e.target.value=''}}
 async function analyze(){if(!paper)return;setAnalyzing(true);setError('');setAnalysis(null);
  try{const blob=await fetch(API+paper.pages[idx].image_url).then(r=>r.blob());const d=new FormData();d.append('image',blob,'page.png');
   const r=await fetch(API+'/api/analyze-question',{method:'POST',body:d});const j=await r.json();if(!r.ok)throw Error(j.detail||'Analysis failed');setAnalysis(j.analysis)}
  catch(x){setError(x.message)}finally{setAnalyzing(false)}}
 const page=paper?.pages[idx];
 return <main className="shell">
  <header><div className="brand"><div className="logo"><BookOpen/></div><div><b>NEET PDF-to-CBT</b><small>Question paper to mock test</small></div></div><span className="pill">FREE · GEMINI AI</span></header>
  <section className="hero"><p className="eyebrow">YOUR QUESTION BANK WORKSPACE</p><h1>Turn NEET PDFs into<br/><span>practice tests.</span></h1><p>Upload a paper, inspect its pages, and use Gemini to analyse a question image and suggest an answer with an explanation.</p></section>
  <section className="upload"><div className="uploadIcon"><Upload/></div><div className="uploadText"><b>Upload question paper</b><small>PDF only · Maximum 100 MB</small></div><label className="btn">{busy?'Processing…':'Choose PDF'}<input type="file" accept="application/pdf,.pdf" onChange={upload} disabled={busy}/></label></section>
  {error&&<div className="error"><AlertCircle size={17}/>{error}</div>}
  {busy&&<p className="notice">Rendering PDF pages…</p>}
  {paper&&<><div className="paperHead"><div><p className="eyebrow">UPLOADED PAPER</p><h2><FileText size={19}/> {paper.filename}</h2><small>{paper.page_count} pages · ID {paper.paper_id}</small></div><span className="ok"><CheckCircle2 size={16}/> Processed</span></div>
   <div className="workspace"><aside><h3>Pages ({paper.page_count})</h3>{paper.pages.map((p,i)=><button className={idx===i?'page active':'page'} key={p.page_number} onClick={()=>{setIdx(i);setAnalysis(null)}}>Page {p.page_number}<small>{p.detected_question_numbers.length?`${p.detected_question_numbers.length} possible labels`:p.text_available?'Text found':'Scanned/image page'}</small></button>)}</aside>
    <section className="preview"><div className="previewHead"><b>Page {page.page_number}</b><button className="aiBtn" onClick={analyze} disabled={analyzing}><Brain size={16}/>{analyzing?'Analysing…':'Analyse with Gemini'}</button></div><img src={API+page.image_url} alt={'PDF page '+page.page_number}/><p className="warning"><AlertCircle size={15}/> This first version analyses the full page. Individual question cropping and correction are the next build stage.</p></section></div>
   {analysis&&<section className="analysis"><div className="analysisTitle"><Brain/> <b>Gemini analysis</b><span>AI suggestion — verify before grading</span></div><p><b>Question:</b> {analysis.question_text}</p><p><b>Options:</b> {analysis.options.join(' · ')||'Not clearly detected'}</p><p><b>Suggested answer:</b> {analysis.suggested_correct_option}</p><p><b>Subject:</b> {analysis.subject} · <b>Confidence:</b> {Math.round(analysis.confidence*100)}%</p><p><b>Explanation:</b> {analysis.explanation}</p>{analysis.uncertainties?.length>0&&<p className="warning">Review: {analysis.uncertainties.join('; ')}</p>}</section>}
  </>}
  {!paper&&!busy&&<div className="steps"><div><b>01</b><strong>Upload PDF</strong><small>Import a NEET paper</small></div><div><b>02</b><strong>Analyse questions</strong><small>Extract, crop and review</small></div><div><b>03</b><strong>Take CBT</strong><small>Attempt and view results</small></div></div>}
  <footer>Gemini suggestions are not an official answer key. Verify every answer before scoring.</footer>
 </main>
}
createRoot(document.getElementById('root')).render(<App/>);
